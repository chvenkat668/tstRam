import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ScrollDirective } from './scroll.directive';
import { FooterfixDirective} from './footerfix.directive';
import { CityComponent } from './city/city.component';
import { HeaderComponent } from './city/header/header.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BodyComponent } from './city/body/body.component';
import { SummaryViewComponent } from './city/summary-view/summary-view.component';
import { DetailsViewComponent } from './city/details-view/details-view.component'
@NgModule({
  declarations: [
    AppComponent,
    ScrollDirective,
    FooterfixDirective,
    CityComponent,
    HeaderComponent,
    BodyComponent,
    SummaryViewComponent,
    DetailsViewComponent
  ],
  imports: [
    NgbModule,
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
