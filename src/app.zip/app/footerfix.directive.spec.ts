import { FooterfixDirective } from './footerfix.directive';

describe('FooterfixDirective', () => {
  it('should create an instance', () => {
    const directive = new FooterfixDirective();
    expect(directive).toBeTruthy();
  });
});
